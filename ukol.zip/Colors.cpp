#include "Colors.h"

const std::vector<std::pair<std::string, glm::vec4>> &Colors::getAllColors() const {
    return this->allColors;
}
