#pragma once
enum class TransformationType
{
	Scale,
	Shift
};