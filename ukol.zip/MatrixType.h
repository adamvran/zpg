#pragma once
enum class MatrixType {
    PROJECTIONMATRIX,
    VIEWMATRIX,
};